# CSCE315_Project3
Project 3 Tic-Tac-Toe


Running Code
We created a make file so all you have to do it put make to compile and ./play to launch the game.Once the game is launched follow the instructions on the screen. 

We were having trouble beating the ai so we put a cheat in so we could show the score working. To win by cheating type w to get a cat by cheating type c. 
